//MAKE NOTE! All the paths are related to the index.html, NOT this file!

scrollPage=function(speedModifier){
    $("*").animate({scrollTop:$("*").height()}, $("*").height()*speedModifier, "linear",function(){
     $("*").animate({scrollTop:0}, 1000)
    });
}
$(document).ready(function(){
    $(".time").text(new Date().toDateString())
    $.get("./slide.html", function(data){
        $(".school-announcement").append(data);
    })
    window.setTimeout(scrollPage, 5000, 50);
})